package lk.ijse.PriskaCinema.dto;

import lombok.*;


@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor


public class ManLoginPageDto {


    private String login_username;
    private String login_password;
}
