package lk.ijse.PriskaCinema.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString

public class EmployeeRegisterDTO {
    private String username;
    private String password;

}
