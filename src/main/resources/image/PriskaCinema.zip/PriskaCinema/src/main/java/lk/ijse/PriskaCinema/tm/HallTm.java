package lk.ijse.PriskaCinema.tm;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor

public class HallTm {

    private String number;
    private String category;
    private String count;





}
