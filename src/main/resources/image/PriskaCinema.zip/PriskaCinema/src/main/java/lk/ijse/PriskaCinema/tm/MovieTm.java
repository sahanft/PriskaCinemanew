package lk.ijse.PriskaCinema.tm;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor

public class MovieTm {

    private String id;
    private String name;
    private String genre;
    private String duration;
    private String time;



}
