package lk.ijse.PriskaCinema.dto;

public class ManagePaymentDto {
}
