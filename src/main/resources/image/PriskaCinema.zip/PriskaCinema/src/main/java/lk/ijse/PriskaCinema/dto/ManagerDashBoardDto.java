package lk.ijse.PriskaCinema.dto;

public class ManagerDashBoardDto {
}
