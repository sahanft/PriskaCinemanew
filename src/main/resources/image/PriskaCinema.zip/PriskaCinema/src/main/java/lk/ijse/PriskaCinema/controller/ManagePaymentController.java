package lk.ijse.PriskaCinema.controller;

public class ManagePaymentController {
}
