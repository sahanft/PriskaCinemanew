package lk.ijse.PriskaCinema.dto;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor

public class ManageProducerDto {

    private String producerid_txt;
    private String name_txt;
    private String address_txt;
    private String mobilenumber_txt;


}











