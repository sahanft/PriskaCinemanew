package lk.ijse.PriskaCinema.model;

public class ManLoginPageModel {
}
