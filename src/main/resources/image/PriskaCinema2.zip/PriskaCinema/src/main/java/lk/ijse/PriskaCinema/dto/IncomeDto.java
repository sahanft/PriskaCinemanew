package lk.ijse.PriskaCinema.dto;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor

public class IncomeDto {


    private String income_txt;
    private String description_txt;
    private String month_txt;
    private Double amount_txt;



}
