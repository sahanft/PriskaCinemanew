package lk.ijse.PriskaCinema.controller;

import javafx.event.ActionEvent;

public class DashBoardController1 {
    public void back_onaction(ActionEvent actionEvent) {

    }
}
