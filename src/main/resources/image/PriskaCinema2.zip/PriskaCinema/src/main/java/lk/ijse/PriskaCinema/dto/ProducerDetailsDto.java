package lk.ijse.PriskaCinema.dto;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor

public class ProducerDetailsDto {

    private String pro_id;
    private String movie_id;

//    public ProducerDetailsDto(String id) {
//    }
}
