package lk.ijse.PriskaCinema.tm;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor

public class ProducerTm {

    private String producerid;
    private String name;
    private String address;
    private String mobilenumber;
}
