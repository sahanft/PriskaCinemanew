package lk.ijse.PriskaCinema.tm;

//import javafx.collections.ObservableList;
//import javafx.scene.control.ChoiceDialog;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString

public class SeateTm {
    private String screen;
    private String row;
    private String seatNumber;



}
